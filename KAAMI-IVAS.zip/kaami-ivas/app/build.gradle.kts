import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}

// Optional release signing: create keystore.properties next to settings.gradle.kts
//   storeFile=kaami-release.jks
//   storePassword=...
//   keyAlias=kaami
//   keyPassword=...
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "com.kaami.ivas"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.kaami.ivas"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        // Fixed relay target. Each install generates its own device key (see DeviceKey.kt) -
        // register that key on this server before expecting OTPs to arrive.
        buildConfigField("String", "SERVER_URL", "\"https://ivas-novahost.my.id\"")

        // VPS mode: when this is not empty the phone only does the one-time iVAS login and
        // uploads the session to your VPS; the VPS keeps it alive and forwards OTPs 24/7
        // (phone can be offline). Leave it "" to use the old on-phone engine.
buildConfigField("String", "VPS_URL", "\"\"")
        // Optional shared secret. If you set ENROLL_TOKEN on the VPS server, put the same value here;
        // the VPS then only auto-registers phones that carry it. Leave "" if the VPS has none.
        buildConfigField("String", "VPS_ENROLL_TOKEN", "\"\"")

        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    signingConfigs {
        if (keystoreProps.containsKey("storeFile")) {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (keystoreProps.containsKey("storeFile")) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    buildFeatures {
        viewBinding = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

chaquopy {
    defaultConfig {
        version = "3.12"
        pip {
            install("requests")
            install("httpx[http2]")
            install("websocket-client")
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
