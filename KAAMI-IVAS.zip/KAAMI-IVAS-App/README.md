# KAAMI-IVAS (Android app) - VPS mode

Phone par sirf iVAS login hota hai. Session VPS par chala jata hai; VPS 24/7 OTP forward karta hai.
Har phone ki apni device key hai; VPS usay pehli baar dekhte hi khud save kar leta hai
(koi key VPS par paste nahi karni).

## Build
1. `kami-ivas/app/build.gradle.kts` mein `VPS_URL` apne VPS ka address rakho (abhi `http://82.38.134.74:8090`).
2. Agar VPS par `ENROLL_TOKEN` lagaya hai to wahi value `VPS_ENROLL_TOKEN` mein rakho, warna `""` rehne do.
3. Android Studio se APK banao (README ke upar wale steps: Open folder -> Sync -> Build APK).
4. `VPS_URL = ""` rakho to app purane tareeqe se (phone par engine) chalegi.

## Use
App kholo -> **Add account** -> email -> iVAS login. Session VPS ko chala jata hai aur app status wahin se dikhati hai.
Har phone, har account ka session VPS par alag save hota hai.
