package com.kaami.ivas

import android.app.Application

class App : Application()
