package com.kaami.ivas

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.kaami.ivas.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private val adapter = AccountAdapter { acc -> openLogin(acc.email) }

    private val poll = object : Runnable {
        override fun run() {
            if (VpsMode.enabled) Thread { VpsClient.sync(this@MainActivity) }.start()
            render()
            handler.postDelayed(this, 2000)
        }
    }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startForwarding() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.rvAccounts.layoutManager = LinearLayoutManager(this)
        b.rvAccounts.adapter = adapter
        b.rvAccounts.isNestedScrollingEnabled = false

        val control = ConnectionSetup.ensure(this)
        b.tvServerValue.text = control.serverUrl
        b.tvDeviceKey.text = control.deviceSecret

        if (VpsMode.enabled) {
            // VPS mode: nothing to start/stop on the phone, the VPS does the work.
            b.tvServerValue.text = VpsMode.baseUrl + "  ->  " + control.serverUrl
            b.btnToggle.visibility = android.view.View.GONE
            b.btnBattery.visibility = android.view.View.GONE
        }

        b.btnToggle.setOnClickListener { toggle() }
        b.btnAdd.setOnClickListener { askEmailThenLogin() }
        b.btnBattery.setOnClickListener { requestBatteryExemption() }
        b.btnShareLog.setOnClickListener { shareLog() }
        b.btnCopyKey.setOnClickListener {
            val key = b.tvDeviceKey.text?.toString().orEmpty()
            if (key.isNotBlank()) {
                val cm = getSystemService(android.content.ClipboardManager::class.java)
                cm.setPrimaryClip(android.content.ClipData.newPlainText("KAAMI-IVAS key", key))
                Toast.makeText(this, R.string.key_copied, Toast.LENGTH_SHORT).show()
            }
        }
        b.tvVersion.text = getString(R.string.version_fmt, BuildConfig.VERSION_NAME)
    }

    override fun onResume() {
        super.onResume()
        handler.post(poll)
    }

    override fun onPause() {
        handler.removeCallbacks(poll)
        super.onPause()
    }

    // ------------------------------------------------------------------ actions

    private fun toggle() {
        if (ServiceController.isWanted(this)) {
            ServiceController.stop(this)
            render()
            return
        }
        ConnectionSetup.ensure(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startForwarding()
        }
    }

    private fun startForwarding() {
        ServiceController.start(this)
        render()
    }

    /** Shares app_state/bot.log so problems can be diagnosed without a PC. */
    private fun shareLog() {
        val f = EnginePaths.logFile(this)
        if (!f.exists() || f.length() == 0L) {
            Toast.makeText(this, R.string.no_log_yet, Toast.LENGTH_SHORT).show()
            return
        }
        val uri = androidx.core.content.FileProvider.getUriForFile(
            this, "$packageName.fileprovider", f
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.share_log)))
    }

    private fun askEmailThenLogin() {
        val input = EditText(this).apply {
            hint = getString(R.string.email_hint)
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS or
                android.text.InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = android.widget.FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.add_account)
            .setMessage(R.string.add_account_msg)
            .setView(holder)
            .setPositiveButton(R.string.continue_label) { _, _ ->
                val email = input.text?.toString().orEmpty().trim()
                if (email.contains("@")) openLogin(email)
                else Toast.makeText(this, R.string.err_email, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun openLogin(email: String) {
        startActivity(Intent(this, LoginActivity::class.java).putExtra(LoginActivity.EXTRA_EMAIL, email))
    }

    private fun requestBatteryExemption() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            Toast.makeText(this, R.string.battery_already, Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                    .setData(Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    // ------------------------------------------------------------------- render

    private fun color(id: Int) = ContextCompat.getColor(this, id)

    private fun render() {
        val wanted = ServiceController.isWanted(this)
        val s = StatusStore.read(this)
        val live = wanted && s != null && s.isFresh

        // top pill
        val (pillText, pillColor) = when {
            !wanted -> R.string.state_stopped to R.color.muted
            live -> R.string.state_running to R.color.ok
            else -> R.string.state_starting to R.color.warn
        }
        b.tvState.setText(pillText)
        b.tvState.backgroundTintList = ColorStateList.valueOf(color(pillColor))

        b.btnToggle.setText(if (wanted) R.string.stop_forwarding else R.string.start_forwarding)

        // hero card
        val relay = if (!wanted || s == null) "idle" else s.relay
        b.tvRelay.setText(
            when (relay) {
                "ok" -> R.string.relay_ok
                "retrying" -> R.string.relay_retrying
                "unauthorized" -> R.string.relay_unauthorized
                "error" -> R.string.relay_error
                "not_configured" -> R.string.relay_not_configured
                else -> R.string.relay_idle
            }
        )
        b.tvRelayDetail.text = when {
            !wanted -> getString(R.string.hint_stopped)
            s == null -> getString(R.string.hint_starting)
            s.relayError.isNotBlank() -> s.relayError
            s.phase == "error" && s.message.isNotBlank() -> s.message
            else -> accountHint(s)
        }
        b.tvSent.text = (s?.sentTotal ?: 0).toString()
        b.tvPending.text = (s?.pending ?: 0).toString()
        b.tvToday.text = (s?.otpToday ?: 0).toString()

        // accounts
        val accounts = s?.accounts ?: emptyList()
        adapter.submit(accounts)
        b.tvNoAccounts.visibility = if (accounts.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun accountHint(s: Status): String = when (s.accState) {
        "no_acc" -> getString(R.string.hint_no_account)
        "session_expired" -> getString(R.string.hint_session_expired)
        "logged_in" -> getString(R.string.hint_logged_in)
        else -> getString(R.string.hint_starting)
    }
}
