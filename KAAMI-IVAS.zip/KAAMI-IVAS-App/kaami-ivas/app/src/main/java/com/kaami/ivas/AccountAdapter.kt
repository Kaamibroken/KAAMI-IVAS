package com.kaami.ivas

import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.kaami.ivas.databinding.ItemAccountBinding

class AccountAdapter(
    private val onClick: (AccountInfo) -> Unit,
) : RecyclerView.Adapter<AccountAdapter.VH>() {

    private var items: List<AccountInfo> = emptyList()

    fun submit(list: List<AccountInfo>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(val b: ItemAccountBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemAccountBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val a = items[position]
        val ctx = holder.b.root.context
        holder.b.tvEmail.text = a.email
        holder.b.tvInitial.text = a.email.firstOrNull()?.uppercase() ?: "?"

        val (label, color) = when (a.state) {
            "active" -> R.string.acc_active to R.color.ok
            "offline" -> R.string.acc_offline to R.color.warn
            else -> R.string.acc_expired to R.color.bad
        }
        holder.b.tvState.setText(label)
        holder.b.tvState.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, color))
        holder.b.root.setOnClickListener { onClick(a) }
    }
}
