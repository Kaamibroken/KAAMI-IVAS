package com.kaami.ivas

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicBoolean

/** Every file the UI process and the ":bot" (Python) process exchange lives here. */
object EnginePaths {
    fun engineDir(ctx: Context): File = File(ctx.filesDir, "engine").also { it.mkdirs() }
    fun stateDir(ctx: Context): File = File(engineDir(ctx), "app_state").also { it.mkdirs() }
    fun inboxDir(ctx: Context): File = File(stateDir(ctx), "inbox").also { it.mkdirs() }
    fun statusFile(ctx: Context): File = File(stateDir(ctx), "status.json")
    fun controlFile(ctx: Context): File = File(stateDir(ctx), "control.json")
    fun logFile(ctx: Context): File = File(stateDir(ctx), "bot.log")
}

/**
 * One random key per install, generated the first time the app runs and never changed after
 * that. Register this key on the server (ivas-novahost.my.id) so it accepts OTPs from this device.
 */
object DeviceKey {
    private const val PREFS = "kaami_prefs"
    private const val KEY = "device_key"

    fun get(ctx: Context): String {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val existing = prefs.getString(KEY, null)
        if (existing != null) return existing

        val bytes = ByteArray(20)
        SecureRandom().nextBytes(bytes)
        val hex = bytes.joinToString("") { "%02x".format(it) }
        val generated = "ivs_$hex"
        prefs.edit().putString(KEY, generated).apply()
        return generated
    }
}

/** No user-entered server/key: the URL is fixed at build time, the key is generated on-device. */
object ConnectionSetup {
    fun ensure(ctx: Context): Control {
        val url = BuildConfig.SERVER_URL
        val key = DeviceKey.get(ctx)
        val current = ControlStore.read(ctx)
        if (current.serverUrl != url || current.deviceSecret != key) {
            ControlStore.write(ctx, url, key)
        }
        return Control(url, key)
    }
}

data class Control(val serverUrl: String, val deviceSecret: String) {
    val isConfigured: Boolean get() = serverUrl.isNotBlank() && deviceSecret.isNotBlank()
}

/** control.json: server URL + API key. Python re-reads it every few seconds. */
object ControlStore {
    fun read(ctx: Context): Control {
        return try {
            val f = EnginePaths.controlFile(ctx)
            if (!f.exists()) return Control("", "")
            val o = JSONObject(f.readText())
            Control(o.optString("server_url", ""), o.optString("device_secret", ""))
        } catch (e: Exception) {
            Control("", "")
        }
    }

    fun write(ctx: Context, serverUrl: String, deviceSecret: String) {
        val o = JSONObject()
            .put("server_url", serverUrl.trim().trimEnd('/'))
            .put("device_secret", deviceSecret.trim())
        val f = EnginePaths.controlFile(ctx)
        val tmp = File(f.parentFile, "control.json.tmp")
        tmp.writeText(o.toString())
        tmp.renameTo(f)
    }
}

data class AccountInfo(val id: Long, val email: String, val state: String)

/** status.json written by android_hooks.py. Field names must match that file. */
data class Status(
    val ts: Long,
    val relay: String,
    val pending: Int,
    val sentTotal: Int,
    val relayError: String,
    val lastSentAt: Long,
    val phase: String,
    val message: String,
    val accState: String,
    val accTotal: Int,
    val accExpired: Int,
    val otpToday: Int,
    val accounts: List<AccountInfo>,
) {
    val isFresh: Boolean get() = ts > 0 && (System.currentTimeMillis() / 1000 - ts) < 20
}

object StatusStore {
    fun read(ctx: Context): Status? {
        return try {
            val f = EnginePaths.statusFile(ctx)
            if (!f.exists()) return null
            val o = JSONObject(f.readText())
            val arr = o.optJSONArray("accounts")
            val list = ArrayList<AccountInfo>()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val a = arr.getJSONObject(i)
                    list.add(AccountInfo(a.optLong("id"), a.optString("email"), a.optString("state")))
                }
            }
            Status(
                ts = o.optLong("ts"),
                relay = o.optString("relay", "not_configured"),
                pending = o.optInt("pending"),
                sentTotal = o.optInt("sent_total"),
                relayError = o.optString("relay_error", ""),
                lastSentAt = o.optLong("last_sent_at"),
                phase = o.optString("phase", ""),
                message = o.optString("message", ""),
                accState = o.optString("acc_state", "starting"),
                accTotal = o.optInt("acc_total"),
                accExpired = o.optInt("acc_expired"),
                otpToday = o.optInt("otp_today"),
                accounts = list,
            )
        } catch (e: Exception) {
            null
        }
    }
}

/** True when a VPS is configured: the phone only logs in, the VPS keeps the session and forwards OTPs. */
object VpsMode {
    val enabled: Boolean get() = BuildConfig.VPS_URL.isNotBlank()
    val baseUrl: String get() = BuildConfig.VPS_URL.trim().trimEnd('/')
}

/**
 * Talks to the VPS server (vps-server/vps_server.py):
 *  - uploads queued sessions (inbox/*.json) to POST /v1/session
 *  - pulls GET /v1/status into status.json so the normal UI shows the VPS state
 * The device key is the Bearer token on both calls.
 */
object VpsClient {
    private val syncing = AtomicBoolean(false)

    private fun open(ctx: Context, path: String, method: String): HttpURLConnection {
        val c = URL(VpsMode.baseUrl + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 8000
        c.readTimeout = 10000
        c.setRequestProperty("Authorization", "Bearer " + DeviceKey.get(ctx))
        if (BuildConfig.VPS_ENROLL_TOKEN.isNotBlank()) c.setRequestProperty("X-Enroll-Token", BuildConfig.VPS_ENROLL_TOKEN)
        return c
    }

    /** Call off the main thread. Safe to call often: overlapping calls are skipped. */
    fun sync(ctx: Context) {
        if (!VpsMode.enabled) return
        if (!syncing.compareAndSet(false, true)) return
        try {
            flushSessions(ctx)
            pullStatus(ctx)
        } finally {
            syncing.set(false)
        }
    }

    private fun flushSessions(ctx: Context) {
        val files = EnginePaths.inboxDir(ctx).listFiles { f -> f.name.endsWith(".json") } ?: return
        for (f in files.sortedBy { it.name }) {
            try {
                val c = open(ctx, "/v1/session", "POST")
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(f.readBytes()) }
                val code = c.responseCode
                c.disconnect()
                if (code in 200..299) {
                    f.delete()
                } else if (code == 401 || code == 403) {
                    return // key not accepted by the VPS: keep the file, stop trying for now
                }
            } catch (e: Exception) {
                return // offline / VPS unreachable: the file stays queued and is retried
            }
        }
    }

    private fun pullStatus(ctx: Context) {
        try {
            val c = open(ctx, "/v1/status", "GET")
            if (c.responseCode !in 200..299) {
                c.disconnect()
                return
            }
            val body = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            val o = JSONObject(body)
            // The VPS clock may differ from the phone clock: use "age" (seconds since the engine
            // last wrote its status) so the UI's freshness check stays correct.
            val age = o.optLong("age", 0L)
            o.put("ts", System.currentTimeMillis() / 1000 - age)
            val f = EnginePaths.statusFile(ctx)
            val tmp = File(f.parentFile, "status.json.tmp")
            tmp.writeText(o.toString())
            tmp.renameTo(f)
        } catch (e: Exception) {
            // keep the last status; it simply turns stale
        }
    }
}

/** Hands a WebView-captured session to the Python engine (it polls the inbox for JSON files). */
object SessionInbox {
    fun submit(ctx: Context, email: String, cookie: String, userAgent: String) {
        val o = JSONObject()
            .put("email", email)
            .put("cookie", cookie)
            .put("ua", userAgent)
            .put("ws_token", "")
            .put("ws_user", "")
            .put("csrf_token", "")
        val dir = EnginePaths.inboxDir(ctx)
        val stamp = System.currentTimeMillis()
        val tmp = File(dir, "$stamp.tmp")
        tmp.writeText(o.toString())
        tmp.renameTo(File(dir, "$stamp.json"))
    }
}

object ServiceController {
    private const val PREFS = "kaami_prefs"
    private const val KEY_RUN = "run_wanted"

    fun isWanted(ctx: Context): Boolean =
        VpsMode.enabled || ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_RUN, false)

    private fun setWanted(ctx: Context, v: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_RUN, v).apply()
    }

    fun start(ctx: Context) {
        if (VpsMode.enabled) return // the VPS runs the engine; never start it on the phone
        setWanted(ctx, true)
        ContextCompat.startForegroundService(ctx, Intent(ctx, ForwarderService::class.java))
    }

    fun stop(ctx: Context) {
        setWanted(ctx, false)
        ctx.stopService(Intent(ctx, ForwarderService::class.java))
    }
}
