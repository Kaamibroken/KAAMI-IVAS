package com.kaami.ivas

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

/** Runs the Python engine in the ":bot" process and keeps it alive 24/7. */
class ForwarderService : Service() {

    @Volatile private var engineStarted = false
    @Volatile private var alive = true

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotification(getString(R.string.notif_starting))
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }

        if (!engineStarted) {
            engineStarted = true
            startEngine()
            startNotificationUpdater()
        }
        return START_STICKY
    }

    private fun startEngine() {
        Thread({
            try {
                if (!Python.isStarted()) Python.start(AndroidPlatform(this))
                val work = EnginePaths.engineDir(this).absolutePath
                Python.getInstance().getModule("bridge").callAttr("start", work, BuildConfig.VERSION_CODE)
            } catch (t: Throwable) {
                Log.e(TAG, "Engine crashed", t)
            }
        }, "kaami-engine").start()
    }

    private fun startNotificationUpdater() {
        Thread({
            val nm = getSystemService(NotificationManager::class.java)
            while (alive) {
                try {
                    Thread.sleep(10_000)
                    val s = StatusStore.read(this)
                    val text = if (s == null) {
                        getString(R.string.notif_starting)
                    } else {
                        getString(R.string.notif_status, s.sentTotal, s.pending)
                    }
                    nm.notify(NOTIF_ID, buildNotification(text))
                } catch (_: InterruptedException) {
                    return@Thread
                } catch (_: Exception) {
                }
            }
        }, "kaami-notif").start()
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_kaami)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        alive = false
        super.onDestroy()
        // The engine is a blocking Python thread; the cleanest stop is ending this process.
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    companion object {
        private const val TAG = "KaamiIvas"
        private const val CHANNEL_ID = "kaami_forwarder"
        private const val NOTIF_ID = 1001
    }
}
