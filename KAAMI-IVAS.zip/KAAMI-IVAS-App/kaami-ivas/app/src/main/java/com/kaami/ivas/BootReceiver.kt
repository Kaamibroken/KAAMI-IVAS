package com.kaami.ivas

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts forwarding after a reboot or an app update, if it was running before. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (ServiceController.isWanted(context) && ControlStore.read(context).isConfigured) {
            try {
                ServiceController.start(context)
            } catch (e: Exception) {
                // Background start can be refused on some OEM builds; the user can reopen the app.
            }
        }
    }
}
