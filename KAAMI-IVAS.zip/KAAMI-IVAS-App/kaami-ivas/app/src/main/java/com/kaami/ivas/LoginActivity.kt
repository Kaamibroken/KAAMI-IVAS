package com.kaami.ivas

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.kaami.ivas.databinding.ActivityLoginBinding

/**
 * Opens the iVAS login page. As soon as the portal loads (login succeeded) the cookies and
 * user-agent are handed to the engine and this screen closes itself.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var b: ActivityLoginBinding
    private var captured = false
    private var email = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)

        email = intent.getStringExtra(EXTRA_EMAIL).orEmpty().trim()
        b.tvTitle.text = if (email.isNotEmpty()) email else getString(R.string.login_title)
        b.btnClose.setOnClickListener { finish() }

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(b.web, true)
        // Start clean so each login belongs to the account the user is adding.
        cm.removeAllCookies(null)
        cm.flush()

        b.web.settings.javaScriptEnabled = true
        b.web.settings.domStorageEnabled = true
        b.web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                b.progress.progress = newProgress
                b.progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }
        b.web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                b.progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                b.progress.visibility = View.GONE
                if (!captured) checkLoggedIn(url)
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (b.web.canGoBack()) b.web.goBack() else finish()
            }
        })

        b.web.loadUrl(LOGIN_URL)
    }

    private fun checkLoggedIn(url: String?) {
        if (url == null) return
        val onPortal = url.contains("ivasms.com") && url.contains("/portal") && !url.contains("login")
        if (!onPortal) return

        val cookie = collectCookies()
        if (cookie.isBlank()) return

        captured = true
        SessionInbox.submit(this, email, cookie, b.web.settings.userAgentString)
        Toast.makeText(this, R.string.login_done, Toast.LENGTH_LONG).show()
        setResult(RESULT_OK)
        finish()
    }

    private fun collectCookies(): String {
        val cm = CookieManager.getInstance()
        val merged = LinkedHashMap<String, String>()
        for (site in listOf("https://www.ivasms.com", "https://ivasms.com")) {
            val raw = cm.getCookie(site) ?: continue
            for (part in raw.split(";")) {
                val kv = part.trim()
                val idx = kv.indexOf('=')
                if (idx > 0) merged[kv.substring(0, idx)] = kv.substring(idx + 1)
            }
        }
        return merged.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    override fun onDestroy() {
        b.web.destroy()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_EMAIL = "email"
        private const val LOGIN_URL = "https://www.ivasms.com/login"
    }
}
