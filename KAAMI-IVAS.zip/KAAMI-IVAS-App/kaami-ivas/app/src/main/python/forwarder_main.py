"""
KAAMI-IVAS engine.

Holds ivasms sessions open on the phone, listens for incoming SMS, and hands
every OTP to the outbox for delivery to the OTP API. No Telegram bot, no number
buying, no admin panel - just login, listen, forward.

This build forwards every message it receives.
"""
import json
import os
import re
import sqlite3
import threading
import time
import urllib.parse
from datetime import datetime, timedelta, timezone

import httpx
import requests
import websocket

import android_hooks
import outbox

# ---------------------------------------------------------------------------
# Config / globals
# ---------------------------------------------------------------------------
IVASMS_URL = "https://www.ivasms.com"
DB_NAME = os.path.join("data", "forwarder.db")

FALLBACK_UA = (
    "Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"
)

WS_KILL_FLAGS = {}          # account_id -> True when the socket must be rebuilt
ACCOUNTS_LOGGING_IN = set()  # account ids currently mid-login (WS threads wait)
OTP_WS_CLIENTS = {}         # account_id -> live WebSocketApp
WS_THREADS = {}             # account_id -> Thread

_CONTROL = {}
_control_lock = threading.Lock()


def get_bd_time():
    return datetime.now(timezone(timedelta(hours=6)))


def add_log(msg, kind="info"):
    stamp = get_bd_time().strftime("%H:%M:%S")
    print("[{}] {} {}".format(stamp, kind.upper()[:4], msg), flush=True)


# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------
def get_db():
    conn = sqlite3.connect(DB_NAME, timeout=30, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=10000")
    return conn


def init_db():
    os.makedirs("data", exist_ok=True)
    conn = get_db()
    conn.execute(
        "CREATE TABLE IF NOT EXISTS ivas_accounts ("
        " id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " email TEXT UNIQUE,"
        " password TEXT,"
        " cookie TEXT,"
        " ws_token TEXT,"
        " ws_user TEXT,"
        " ua TEXT,"
        " csrf_token TEXT,"
        " status TEXT DEFAULT 'Active',"
        " login_retries INTEGER DEFAULT 0,"
        " last_sync TIMESTAMP)"
    )
    conn.execute(
        "CREATE TABLE IF NOT EXISTS otp_history ("
        " id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " number TEXT,"
        " otp TEXT,"
        " service TEXT,"
        " range_name TEXT,"
        " time TEXT)"
    )
    conn.execute("CREATE INDEX IF NOT EXISTS ix_otp_time ON otp_history(time)")
    conn.commit()
    conn.close()


def get_accounts():
    conn = get_db()
    rows = conn.execute("SELECT * FROM ivas_accounts").fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------
def get_client():
    return httpx.Client(http2=True, verify=True)


def get_headers(account_row, referer=None):
    referer = referer or (IVASMS_URL + "/portal/numbers")
    cookie_str = account_row.get("cookie") or ""
    csrf = account_row.get("csrf_token") or ""

    # Laravel keeps the CSRF token in the XSRF-TOKEN cookie as well
    if not csrf and "XSRF-TOKEN=" in cookie_str:
        try:
            csrf = urllib.parse.unquote(
                cookie_str.split("XSRF-TOKEN=")[1].split(";")[0]
            )
        except Exception:
            csrf = ""

    return {
        "User-Agent": account_row.get("ua") or FALLBACK_UA,
        "Cookie": cookie_str,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate",
        "Referer": referer,
        "Origin": IVASMS_URL,
        "X-Requested-With": "XMLHttpRequest",
        "x-csrf-token": csrf,
        "Upgrade-Insecure-Requests": "1",
    }


def validate_account_session(account_id):
    """True when the stored cookie still opens the portal."""
    conn = get_db()
    row = conn.execute("SELECT * FROM ivas_accounts WHERE id=?", (account_id,)).fetchone()
    conn.close()
    if not row:
        return False
    acc = dict(row)
    if not acc.get("cookie"):
        return False
    try:
        with get_client() as client:
            res = client.get(
                IVASMS_URL + "/portal/numbers",
                headers=get_headers(acc),
                timeout=15,
                follow_redirects=True,
            )
        return res.status_code == 200 and "login" not in str(res.url)
    except Exception:
        return False


def extract_ws_tokens_from_portal(account_id, cookie_str, user_agent):
    """Fetch a portal page and pull the socket.io token/user out of its HTML."""
    ws_token, ws_user, csrf_token = "", "", ""
    try:
        headers = {
            "User-Agent": user_agent or FALLBACK_UA,
            "Cookie": cookie_str,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate",
            "Referer": IVASMS_URL + "/portal",
            "Upgrade-Insecure-Requests": "1",
        }

        html = ""
        for path in ("/portal/live/test_sms", "/portal/numbers", "/portal"):
            try:
                with get_client() as client:
                    res = client.get(
                        IVASMS_URL + path, headers=headers, timeout=20, follow_redirects=True
                    )
                if res.status_code == 200 and "login" not in str(res.url):
                    html = res.text or ""
                    if html and re.search(r"eyJ[a-zA-Z0-9_\-=.]{50,}", html):
                        break
            except Exception:
                continue

        if not html:
            add_log("Portal fetch returned nothing for account {}.".format(account_id), "warning")
            return

        m = (
            re.search(r'content="([^"]+)" name="csrf-token"', html)
            or re.search(r'name="csrf-token" content="([^"]+)"', html)
            or re.search(r'name="_token" value="([^"]+)"', html)
        )
        if m:
            csrf_token = m.group(1)

        m = (
            re.search(r'token\s*:\s*[\'\"](eyJ[a-zA-Z0-9_\-=.]{50,})[\'\"]', html)
            or re.search(r"[?&]token=(eyJ[a-zA-Z0-9_\-=.]+)", html)
        )
        if m:
            ws_token = m.group(1).rstrip("\"'&")

        m = (
            re.search(r'user\s*:\s*[\"\']([a-f0-9]{32})[\"\']', html)
            or re.search(r"[?&]user=([a-f0-9]{32})", html)
        )
        if m:
            ws_user = m.group(1)

        conn = get_db()
        if ws_token and ws_user:
            conn.execute(
                "UPDATE ivas_accounts SET ws_token=?, ws_user=?, csrf_token=?,"
                " login_retries=0, ua=? WHERE id=?",
                (ws_token, ws_user, csrf_token, user_agent or FALLBACK_UA, account_id),
            )
            add_log("WS tokens recovered over HTTP for account {}.".format(account_id), "success")
        elif csrf_token:
            conn.execute(
                "UPDATE ivas_accounts SET csrf_token=? WHERE id=?", (csrf_token, account_id)
            )
            add_log("CSRF recovered for account {} (WS token missing).".format(account_id), "info")
        else:
            add_log("Could not extract WS tokens for account {}.".format(account_id), "warning")
        conn.commit()
        conn.close()
    except Exception as e:
        add_log("Portal token extraction error: {}".format(e), "error")


def apply_app_session(account_id, cookie_str, user_agent, ws_token, ws_user, csrf_token):
    """Store a session captured by the app's WebView login and restart the socket."""
    try:
        conn = get_db()
        if ws_token and ws_user:
            conn.execute(
                "UPDATE ivas_accounts SET cookie=?, ua=?, csrf_token=?, ws_token=?,"
                " ws_user=?, login_retries=0, status='Active' WHERE id=?",
                (cookie_str, user_agent, csrf_token, ws_token, ws_user, account_id),
            )
        else:
            conn.execute(
                "UPDATE ivas_accounts SET cookie=?, ua=?, csrf_token=?,"
                " login_retries=0, status='Active' WHERE id=?",
                (cookie_str, user_agent, csrf_token, account_id),
            )
        conn.commit()
        conn.close()

        if not ws_token or not ws_user:
            extract_ws_tokens_from_portal(account_id, cookie_str, user_agent)

        WS_KILL_FLAGS[account_id] = True
        add_log("App login applied for account {}.".format(account_id), "success")
        return True
    except Exception as e:
        add_log("apply_app_session failed for {}: {}".format(account_id, e), "error")
        return False


def trigger_relogin(reason="", account_id=None, force=False):
    """Tell the app this account needs a fresh login."""
    if not account_id:
        return
    conn = get_db()
    row = conn.execute("SELECT email FROM ivas_accounts WHERE id=?", (account_id,)).fetchone()
    conn.close()
    email = row["email"] if row else str(account_id)
    add_log("Session problem for {} ({}).".format(email, reason), "warning")
    android_hooks.mark_needs_login(account_id, email)


# ---------------------------------------------------------------------------
# OTP handling
# ---------------------------------------------------------------------------
def extract_otp(text):
    clean_text = re.sub(r"<[^<]+?>", " ", text or "").strip()
    clean_text = clean_text.replace("&lt;#&gt;", "").replace("<#>", "").strip()

    patterns = [
        r"(?:WhatsApp code|code|otp|pin)\s*[:is\s-]*(\d{3}-\d{3})",
        r"(?:code|otp|pin)\s*[:is\s-]*(\d{3}[\s-]?\d{3})",
        r"(?:code|otp|pin)\s*[:is\s-]*(\d{4,8})",
        r"\b(\d{3}-\d{3})\b",
        r"\b(\d{4,8})\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, clean_text, re.IGNORECASE)
        if match:
            return match.group(1).replace("-", "").replace(" ", "")

    if "code" in clean_text.lower() or "otp" in clean_text.lower():
        match = re.search(r"\b(\d{4,6})\b", clean_text)
        if match:
            return match.group(1)
    return None


def extract_service(text):
    """
    Fallback service/sender name when ivasms.com's live socket does not send
    one (payload has no "cli"). Takes the word(s) right before the first
    code/otp/pin/verification keyword, e.g. "HouseOfFun code: 6509" -> "HouseOfFun".
    """
    clean_text = re.sub(r"<[^<]+?>", " ", text or "").strip()
    if not clean_text:
        return None

    patterns = [
        # "... is your Google verification code"
        r"is\s+your\s+([A-Za-z][A-Za-z0-9 .&'_-]{1,30}?)\s+(?:verification\s+)?(?:code|otp|pin)\b",
        # "HouseOfFun code: 6509" / "Your WhatsApp code" / "Facebook verification code"
        r"^(?:your\s+)?([A-Za-z][A-Za-z0-9 .&'_-]{1,30}?)\s+(?:verification\s+)?(?:code|otp|pin)\b",
    ]
    for pattern in patterns:
        match = re.search(pattern, clean_text, re.IGNORECASE)
        if match:
            name = match.group(1).strip(" .-_'")
            if name:
                return name
    return None


def record_and_forward(number, otp, service, range_name, country, language, body):
    received_at = int(time.time())

    queued = outbox.enqueue(
        number=number,
        otp=otp,
        service=service,
        range_name=range_name,
        country=country,
        language=language,
        body=body,
        received_at=received_at,
    )
    if not queued:
        return  # duplicate

    try:
        conn = get_db()
        conn.execute(
            "INSERT INTO otp_history (number, otp, service, range_name, time) VALUES (?,?,?,?,?)",
            (number, otp, service, range_name, get_bd_time().strftime("%Y-%m-%d %H:%M:%S")),
        )
        conn.commit()
        conn.close()
    except Exception as e:
        add_log("otp_history insert failed: {}".format(e), "warning")

    add_log(
        "OTP {} for {} queued ({} pending).".format(
            otp or "-", number, outbox.STATE.get("pending", 0)
        ),
        "success",
    )


# ---------------------------------------------------------------------------
# Live SMS socket (socket.io v4 over websocket, namespace /livesms)
# ---------------------------------------------------------------------------
def individual_websocket_thread(account_row):
    backoff = 2
    max_backoff = 60
    consecutive_failures = 0
    acc_id = account_row.get("id")

    while True:
        try:
            if acc_id in ACCOUNTS_LOGGING_IN:
                time.sleep(2)
                continue

            if WS_KILL_FLAGS.get(acc_id):
                WS_KILL_FLAGS[acc_id] = False
                backoff = 2
                time.sleep(backoff)

            # always work from the freshest row
            conn = get_db()
            updated = conn.execute(
                "SELECT * FROM ivas_accounts WHERE id=?", (acc_id,)
            ).fetchone()
            conn.close()
            if not updated:
                add_log("Account {} no longer exists. WS thread exiting.".format(acc_id), "warning")
                WS_THREADS.pop(acc_id, None)
                return

            account_row = dict(updated)
            email = account_row.get("email", "?")
            token = account_row.get("ws_token") or ""
            user = account_row.get("ws_user") or ""

            if not token or not user:
                if account_row.get("cookie"):
                    extract_ws_tokens_from_portal(acc_id, account_row["cookie"], account_row.get("ua"))
                    conn = get_db()
                    again = conn.execute(
                        "SELECT ws_token, ws_user FROM ivas_accounts WHERE id=?", (acc_id,)
                    ).fetchone()
                    conn.close()
                    token = (again["ws_token"] if again else "") or ""
                    user = (again["ws_user"] if again else "") or ""

                if not token or not user:
                    trigger_relogin("missing live tokens", account_id=acc_id)
                    WS_THREADS.pop(acc_id, None)
                    return

            # --- step 1: engine.io polling handshake to get a session id ----
            sid = None
            poll_params = {"token": token, "user": user, "EIO": "4", "transport": "polling"}
            poll_url = "https://ivasms.com:2087/socket.io/?" + urllib.parse.urlencode(poll_params)
            poll_headers = {
                "User-Agent": account_row.get("ua") or FALLBACK_UA,
                "Origin": IVASMS_URL,
                "Cookie": account_row.get("cookie", ""),
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.9",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
            }
            try:
                with requests.get(poll_url, headers=poll_headers, timeout=10) as resp:
                    if resp.status_code == 200 and resp.text.startswith("0"):
                        sid = json.loads(resp.text[1:]).get("sid")
            except Exception:
                pass  # fall back to a direct websocket connection

            # --- step 2: upgrade to websocket ------------------------------
            ws_params = {"EIO": "4", "transport": "websocket"}
            if sid:
                ws_params["sid"] = sid
            else:
                ws_params["token"] = token
                ws_params["user"] = user
            ws_url = "wss://ivasms.com:2087/socket.io/?" + urllib.parse.urlencode(ws_params)

            headers = [
                "User-Agent: " + (account_row.get("ua") or FALLBACK_UA),
                "Origin: " + IVASMS_URL,
                "Cookie: " + (account_row.get("cookie") or ""),
                "Accept-Encoding: gzip, deflate",
                "Accept-Language: en-US,en;q=0.9",
                "Cache-Control: no-cache",
                "Pragma: no-cache",
            ]

            ws_connected = [False]
            joined = [False]

            def on_message(ws, message):
                try:
                    if message.startswith("0"):
                        # engine.io open packet (direct connect) -> join namespace
                        ws.send("40/livesms,")
                        return
                    if message == "3probe":
                        ws.send("5")  # complete the upgrade
                        ws.send("40/livesms,")
                        return
                    if message.startswith("40"):
                        if not joined[0]:
                            joined[0] = True
                            add_log("Live SMS ready for {}.".format(email), "success")
                        return
                    if message.strip() == "2":
                        ws.send("3")  # pong
                        return
                    if message.startswith("42/livesms,"):
                        data = json.loads(message.replace("42/livesms,", "", 1))
                        if not (isinstance(data, list) and len(data) >= 2 and isinstance(data[1], dict)):
                            return
                        payload = data[1]

                        recipient = str(payload.get("recipient", "")).replace("+", "").strip()
                        body = payload.get("message", "")
                        if not recipient:
                            return

                        rng = payload.get("range") or "Unknown"
                        country = rng.split(" ")[0] if rng else "Unknown"
                        language = payload.get("Language") or payload.get("language")
                        if language and str(language).lower() == "unknown":
                            language = None
                        service = payload.get("cli") or payload.get("service") or extract_service(body)

                        record_and_forward(
                            number=recipient,
                            otp=extract_otp(body),
                            service=service,
                            range_name=rng,
                            country=country,
                            language=language,
                            body=body,
                        )
                except Exception as e:
                    add_log("WS message parse failed: {}".format(e), "warning")

            def on_error(ws, error):
                error_str = str(error)
                if any(c in error_str for c in ("401", "403", "Unauthorized", "forbidden", "Empty response")):
                    add_log("WS auth error for {}: {}".format(email, error_str[:90]), "warning")
                    trigger_relogin("WS auth error", account_id=acc_id, force=True)
                    return
                add_log("WS error for {}: {}".format(email, error_str[:90]), "warning")

            def on_close(ws, close_status_code, close_msg):
                OTP_WS_CLIENTS.pop(acc_id, None)
                if close_status_code in (4001, 4003, 1008):
                    add_log("WS closed (auth) for {}.".format(email), "warning")
                    trigger_relogin("WS close auth", account_id=acc_id, force=True)

            def on_open(ws):
                OTP_WS_CLIENTS[acc_id] = ws
                ws_connected[0] = True
                if sid:
                    ws.send("2probe")
                    add_log("Live SMS socket upgrading for {}.".format(email), "info")
                else:
                    add_log("Live SMS socket open for {}.".format(email), "info")

            ws_app = websocket.WebSocketApp(
                ws_url,
                header=headers,
                on_open=on_open,
                on_message=on_message,
                on_error=on_error,
                on_close=on_close,
            )

            # When a fresh session is installed, drop the old socket right away
            # instead of waiting for it to time out.
            stop_watch = threading.Event()

            def _kill_watch(app=ws_app, stop=stop_watch):
                while not stop.wait(1):
                    if WS_KILL_FLAGS.get(acc_id):
                        try:
                            app.close()
                        except Exception:
                            pass
                        return

            threading.Thread(target=_kill_watch, daemon=True).start()

            try:
                ws_app.run_forever(ping_interval=0, ping_timeout=20, reconnect=0)
            finally:
                stop_watch.set()

            if ws_connected[0]:
                backoff = 5
                consecutive_failures = 0
            else:
                consecutive_failures += 1
                backoff = min(backoff * 2, max_backoff)
                if consecutive_failures >= 3:
                    add_log("WS failed 3x for {}. Asking for a re-login.".format(email), "warning")
                    trigger_relogin("3 consecutive WS failures", account_id=acc_id, force=True)
                    WS_THREADS.pop(acc_id, None)
                    return

            time.sleep(backoff)

        except Exception as e:
            add_log("WS thread error: {}".format(e), "error")
            consecutive_failures += 1
            time.sleep(min(backoff * 2, max_backoff))


def websocket_manager():
    """Keep one live-SMS thread per usable account."""
    while True:
        try:
            for acc in get_accounts():
                acc_id = acc["id"]
                thread = WS_THREADS.get(acc_id)
                if thread and thread.is_alive():
                    continue
                if not acc.get("cookie"):
                    continue
                if str(acc.get("status") or "").lower() == "expired":
                    continue

                t = threading.Thread(
                    target=individual_websocket_thread,
                    args=(acc,),
                    name="ws-{}".format(acc_id),
                    daemon=True,
                )
                t.start()
                WS_THREADS[acc_id] = t
                add_log("Started live socket thread for {}.".format(acc.get("email")), "info")
        except Exception as e:
            add_log("websocket_manager error: {}".format(e), "error")
        time.sleep(10)


# ---------------------------------------------------------------------------
# control.json (server URL + device secret written by the app)
# ---------------------------------------------------------------------------
def load_control():
    path = os.path.join("app_state", "control.json")
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        with _control_lock:
            _CONTROL.clear()
            _CONTROL.update(data)
    except Exception:
        pass
    return dict(_CONTROL)


def get_control():
    with _control_lock:
        return dict(_CONTROL)


def _control_watcher():
    last = None
    while True:
        try:
            path = os.path.join("app_state", "control.json")
            stamp = os.path.getmtime(path) if os.path.exists(path) else None
            if stamp != last:
                last = stamp
                load_control()
        except Exception:
            pass
        time.sleep(3)


def boot():
    init_db()
    load_control()

    outbox.init(DB_NAME, get_control, log=add_log)

    android_hooks.start(
        apply_session=apply_app_session,
        validate_session=validate_account_session,
        get_db=get_db,
        get_bd_time=get_bd_time,
        add_log=add_log,
        notify_admins=None,
        relay_state=outbox.STATE,
    )

    outbox.start()

    threading.Thread(target=_control_watcher, daemon=True).start()
    threading.Thread(target=websocket_manager, daemon=True).start()

    android_hooks.set_phase("running")
    add_log("Forwarder engine running.", "success")

    while True:
        time.sleep(3600)


if __name__ == "__main__":
    boot()
