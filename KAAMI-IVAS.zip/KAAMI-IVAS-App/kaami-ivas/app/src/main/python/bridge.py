"""
Entry point called from ForwarderService.kt (Chaquopy).

Chdir into the app's private working directory first, so the engine's relative
paths (data/forwarder.db, app_state/) resolve inside it.
"""
import io
import json
import os
import sys
import time
import traceback

_LOG_LIMIT = 512 * 1024


class _Tee(io.TextIOBase):
    """Send Python output to logcat (via the original stream) and to bot.log."""

    def __init__(self, original, path):
        self._original = original
        self._path = path
        self._fh = open(path, "a", encoding="utf-8", errors="replace")

    def write(self, s):
        try:
            self._original.write(s)
        except Exception:
            pass
        try:
            self._fh.write(s)
            self._fh.flush()
            if self._fh.tell() > _LOG_LIMIT:
                self._rotate()
        except Exception:
            pass
        return len(s)

    def _rotate(self):
        try:
            self._fh.close()
            with open(self._path, "r", encoding="utf-8", errors="replace") as f:
                tail = f.read()[-(_LOG_LIMIT // 2):]
            with open(self._path, "w", encoding="utf-8") as f:
                f.write(tail)
            self._fh = open(self._path, "a", encoding="utf-8", errors="replace")
        except Exception:
            return

    def flush(self):
        try:
            self._original.flush()
        except Exception:
            pass
        try:
            self._fh.flush()
        except Exception:
            return


def _setup_logging(state_dir):
    log_path = os.path.join(state_dir, "bot.log")
    sys.stdout = _Tee(sys.stdout, log_path)
    sys.stderr = _Tee(sys.stderr, log_path)


def _load_control(state_dir):
    path = os.path.join(state_dir, "control.json")
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _write_fatal(state_dir, msg):
    """Leave a status.json behind so the UI can explain a boot failure."""
    try:
        with open(os.path.join(state_dir, "status.json"), "w", encoding="utf-8") as f:
            json.dump({
                "ts": int(time.time()),
                "tg_bot": False,
                "relay": "error",
                "pending": 0,
                "phase": "error",
                "message": msg[:400],
                "acc_state": "no_acc",
                "acc_total": 0,
                "acc_expired": 0,
                "otp_today": 0,
                "accounts": [],
            }, f)
    except Exception:
        return


def start(work_dir, version_code=0):
    """Called from ForwarderService. Blocks until the process is killed."""
    os.makedirs(work_dir, exist_ok=True)
    os.chdir(work_dir)

    state_dir = os.path.join(work_dir, "app_state")
    os.makedirs(os.path.join(state_dir, "inbox"), exist_ok=True)
    os.makedirs(os.path.join(work_dir, "data"), exist_ok=True)

    _setup_logging(state_dir)

    print("=" * 60, flush=True)
    print("KAAMI-IVAS starting  |  build {}  |  cwd {}".format(version_code, os.getcwd()), flush=True)
    print("=" * 60, flush=True)

    control = _load_control(state_dir)
    if not (control.get("server_url") or "").strip():
        print("[warn] No API server configured yet - OTPs will queue locally.", flush=True)

    try:
        import forwarder_main
        forwarder_main.boot()
    except SystemExit as e:
        msg = str(e) or "Bot exited."
        print("[EXIT] {}".format(msg), flush=True)
        _write_fatal(state_dir, msg)
    except Exception:
        tb = traceback.format_exc()
        print(tb, flush=True)
        _write_fatal(state_dir, tb.strip().splitlines()[-1])
        raise
