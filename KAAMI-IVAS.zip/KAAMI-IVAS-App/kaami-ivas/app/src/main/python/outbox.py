"""
Durable OTP queue.

The WebSocket is the only source of OTPs, so anything received has to survive
a flaky network, a server restart, or the user walking out of Wi-Fi range.
Every OTP is written to SQLite first and only leaves the queue once the API
has acknowledged it.

    receive -> enqueue() -> [outbox table] -> pusher thread -> POST /v1/msg?key=...
                                                    |           (all due OTPs batched
                                                    |            into one call, as
                                                    |            {"otps": [...]})
                                               ok -> delete all
                                            other -> exponential backoff (all)
"""
import hashlib
import json
import sqlite3
import threading
import time

import requests

BATCH = 50
IDLE_SLEEP = 2.0
HEARTBEAT_EVERY = 60
MAX_BACKOFF = 300
GIVE_UP_AFTER = 86400  # 24h

_lock = threading.Lock()
_db_path = None
_get_config = None
_started = False


def _default_log(msg, kind="info"):
    print("[outbox] {}".format(msg), flush=True)


_log = _default_log

STATE = {
    "relay": "not_configured",
    "pending": 0,
    "sent_total": 0,
    "last_error": "",
    "last_sent_at": 0,
}


def _conn():
    c = sqlite3.connect(_db_path, timeout=20)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    return c


def init(db_path, get_config, log=None):
    global _db_path, _get_config, _log
    _db_path = db_path
    _get_config = get_config
    if log:
        _log = log

    c = _conn()
    c.execute(
        "CREATE TABLE IF NOT EXISTS outbox ("
        " id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " dedup_id TEXT NOT NULL UNIQUE,"
        " payload TEXT NOT NULL,"
        " created_at INTEGER NOT NULL,"
        " tries INTEGER NOT NULL DEFAULT 0,"
        " next_try_at INTEGER NOT NULL DEFAULT 0,"
        " last_error TEXT)"
    )
    c.execute("CREATE INDEX IF NOT EXISTS ix_outbox_next ON outbox(next_try_at, id)")
    c.commit()
    c.close()
    _refresh_pending()


def dedup_id(number, otp, body, received_at):
    raw = "{}|{}|{}|{}".format(number or "", otp or "", body or "", received_at or "")
    return hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()


def enqueue(number=None, otp=None, service=None, range_name=None, country=None,
            language=None, body=None, received_at=None):
    """Queue one OTP. True if it was new, False if it was already waiting."""
    received_at = int(received_at or time.time())
    did = dedup_id(number, otp, body, received_at)
    payload = {
        "dedup_id": did,
        "number": number,
        "otp": otp,
        "service": service,
        "range": range_name,
        "country": country,
        "language": language,
        "body": body,
        "received_at": received_at * 1000,  # panel stores/returns epoch milliseconds
    }
    try:
        with _lock:
            c = _conn()
            cur = c.execute(
                "INSERT OR IGNORE INTO outbox (dedup_id, payload, created_at, next_try_at)"
                " VALUES (?, ?, ?, 0)",
                (did, json.dumps(payload), int(time.time())),
            )
            c.commit()
            c.close()
        _refresh_pending()
        return cur.rowcount > 0
    except Exception as e:
        _log("enqueue failed: {}".format(e), "error")
        return False


def _refresh_pending():
    try:
        c = _conn()
        STATE["pending"] = c.execute("SELECT COUNT(*) FROM outbox").fetchone()[0]
        c.close()
    except Exception:
        return


def _due_batch():
    c = _conn()
    rows = c.execute(
        "SELECT id, payload, tries, created_at FROM outbox"
        " WHERE next_try_at <= ? ORDER BY id ASC LIMIT ?",
        (int(time.time()), BATCH),
    ).fetchall()
    c.close()
    return rows


def _delete(ids):
    if not ids:
        return
    c = _conn()
    marks = ",".join(["?"] * len(ids))
    c.execute("DELETE FROM outbox WHERE id IN ({})".format(marks), ids)
    c.commit()
    c.close()


def _defer(ids, error):
    """Back off, doubling per attempt, so a dead server is not hammered."""
    if not ids:
        return
    c = _conn()
    for rid in ids:
        row = c.execute("SELECT tries FROM outbox WHERE id=?", (rid,)).fetchone()
        tries = (row["tries"] if row else 0) + 1
        delay = min(MAX_BACKOFF, 3 * (2 ** min(tries, 7)))
        c.execute(
            "UPDATE outbox SET tries=?, next_try_at=?, last_error=? WHERE id=?",
            (tries, int(time.time()) + delay, str(error)[:300], rid),
        )
    c.commit()
    c.close()


def _drop_expired(rows):
    """Discard OTPs older than the server would have kept anyway."""
    cutoff = int(time.time()) - GIVE_UP_AFTER
    dead = [r["id"] for r in rows if r["created_at"] < cutoff]
    if dead:
        _delete(dead)
        _log("Dropped {} queued OTP(s) older than 24h.".format(len(dead)), "warning")
    return [r for r in rows if r["created_at"] >= cutoff]


def _config():
    cfg = _get_config() or {}
    base = (cfg.get("server_url") or "").rstrip("/")
    secret = cfg.get("device_secret") or ""
    return base, secret


def _push_once(session):
    base, secret = _config()
    if not base or not secret:
        STATE["relay"] = "not_configured"
        return False

    rows = _drop_expired(_due_batch())
    if not rows:
        if STATE["relay"] in ("retrying", "not_configured"):
            STATE["relay"] = "ok"
        return False

    ids = [row["id"] for row in rows]
    items = [json.loads(row["payload"]) for row in rows]

    try:
        resp = session.post(
            base + "/v1/msg",
            params={"key": secret},
            json={"otps": items},
            timeout=20,
        )
    except Exception as e:
        STATE["relay"] = "retrying"
        STATE["last_error"] = str(e)[:200]
        _defer(ids, e)
        _refresh_pending()
        return False

    if resp.status_code in (401, 403):
        STATE["relay"] = "unauthorized"
        STATE["last_error"] = "server rejected the device secret ({})".format(resp.status_code)
        _defer(ids, STATE["last_error"])
        _refresh_pending()
        return False

    ok = False
    if resp.status_code in (200, 201):
        try:
            ok = bool(resp.json().get("ok", True))
        except Exception:
            ok = True

    sent_any = False
    if ok:
        _delete(ids)
        STATE["relay"] = "ok"
        STATE["last_error"] = ""
        STATE["sent_total"] += len(ids)
        STATE["last_sent_at"] = int(time.time())
        sent_any = True
    else:
        STATE["relay"] = "retrying"
        STATE["last_error"] = "HTTP {}".format(resp.status_code)
        _defer(ids, STATE["last_error"])

    _refresh_pending()
    if sent_any:
        _log("Forwarded {} OTP(s) to the API in one call.".format(len(ids)), "success")
    return sent_any


def _heartbeat(session):
    base, secret = _config()
    if not base or not secret:
        return
    try:
        session.post(
            base + "/v1/heartbeat",
            params={"key": secret},
            timeout=15,
        )
    except Exception:
        return


def _pusher():
    session = requests.Session()
    last_beat = 0
    while True:
        try:
            # drain in bursts while there is work, then idle
            while _push_once(session) and _push_once(session):
                pass
            if time.time() - last_beat > HEARTBEAT_EVERY:
                _heartbeat(session)
                last_beat = time.time()
        except Exception as e:
            _log("pusher error: {}".format(e), "error")
        time.sleep(IDLE_SLEEP)


def start():
    global _started
    if _started:
        return
    _started = True
    threading.Thread(target=_pusher, name="outbox-pusher", daemon=True).start()
    _log("Outbox pusher started.", "info")
