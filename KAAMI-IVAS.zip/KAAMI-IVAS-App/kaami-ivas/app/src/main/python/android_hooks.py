"""
Glue between forwarder_main.py and the Android app.

Two directions of traffic, both over plain files inside app_state/ so that the
UI process and the ":bot" process never have to share a socket or a database
handle:

    engine -> app :  status.json   (state, refreshed every few seconds)
    app -> engine :  inbox/*.json  (sessions captured by the WebView login)
    app -> engine :  control.json  (server URL and credentials)

Keep the status.json field names in sync with Core.kt (StatusStore).
"""
import json
import os
import threading
import time
import traceback

_STATE_DIR = None
_INBOX_DIR = None
_STATUS_FILE = None
_lock = threading.Lock()

_tg_alive = False
_phase = "starting"
_message = ""
_started = False

# account_id -> True once the "session expired" notice was shown
_notified = {}
# account_id -> unix time until which expiry signals are ignored
# (a freshly installed session may still trigger stale expiry events)
_grace = {}
GRACE_SECONDS = 120

# True after the first inbox scan, so the UI can tell "no accounts" from "still loading"
_first_drain_done = False

_apply_session = None
_validate_session = None
_relay_state = None
_get_db = None
_get_bd_time = None
_add_log = None
_notify_admins = None


def _log(msg, kind="info"):
    try:
        if _add_log:
            _add_log(msg, kind)
            return
    except Exception:
        pass
    print(f"[android_hooks] {msg}", flush=True)


def set_tg_bot_alive(alive):
    global _tg_alive
    _tg_alive = bool(alive)


def set_phase(phase, message=""):
    global _phase, _message
    _phase = phase
    _message = message


def mark_needs_login(account_id, email=""):
    """
    Called by the engine when a session stops working.

    Ignored during the grace window after a fresh login. If a validator is
    available it is asked first, so a single failed request does not throw
    away a good session.
    """
    try:
        if time.time() < _grace.get(account_id, 0):
            _log(f"Expiry signal for {email or account_id} ignored - session was just installed.", "info")
            return

        try:
            if _validate_session and _validate_session(account_id):
                _log(f"Expiry signal for {email or account_id} was a false alarm - "
                     f"the portal still answers. Keeping the session.", "info")
                return
        except Exception:
            pass

        try:
            conn = _get_db()
            conn.execute(
                "UPDATE ivas_accounts SET status='Expired', ws_token='', ws_user='' WHERE id=?",
                (account_id,),
            )
            conn.commit()
            conn.close()
        except Exception as e:
            _log(f"mark_needs_login db error: {e}", "error")

        if not _notified.get(account_id):
            _notified[account_id] = True
            _log(f"Session expired for {email or account_id}. Waiting for app login.", "warning")
            if _notify_admins:
                _notify_admins(
                    f"🔐 <b>Session Expired</b>\n\nAccount: <code>{email or account_id}</code>"
                    f"\n\nOpen the app → <b>Login Account</b> and sign in again.",
                    parse_mode="HTML",
                )
    except Exception:
        return


def _bd_midnight_str():
    """Start of the current Bangladesh day, in the format otp_history uses."""
    now = _get_bd_time()
    return now.replace(hour=0, minute=0, second=0, microsecond=0).strftime("%Y-%m-%d %H:%M:%S")


def _collect_status():
    accounts = []
    acc_total = 0
    acc_expired = 0
    otp_today = 0

    try:
        conn = _get_db()
        rows = conn.execute(
            "SELECT id, email, status, cookie, ws_token FROM ivas_accounts"
        ).fetchall()

        for r in rows:
            acc_total += 1
            status = str(r["status"] or "").lower()
            has_session = bool(r["cookie"])
            if status == "expired" or not has_session:
                state = "expired"
                acc_expired += 1
            elif status == "offline":
                state = "offline"
                acc_expired += 1
            else:
                state = "active"
            accounts.append({"id": r["id"], "email": r["email"], "state": state})

        try:
            row = conn.execute(
                "SELECT COUNT(*) AS c FROM otp_history WHERE time >= ?",
                (_bd_midnight_str(),),
            ).fetchone()
            otp_today = int(row["c"] or 0)
        except Exception:
            otp_today = 0

        conn.close()
    except Exception as e:
        _log(f"status collect error: {e}", "warning")

    if not _first_drain_done:
        acc_state = "starting"
    elif acc_total == 0:
        acc_state = "no_acc"
    elif acc_expired >= acc_total:
        acc_state = "session_expired"
    elif acc_expired > 0:
        # some accounts work, some don't - still worth telling the user
        acc_state = "session_expired"
    else:
        acc_state = "logged_in"

    relay = dict(_relay_state) if _relay_state else {}

    return {
        "ts": int(time.time()),
        "tg_bot": _tg_alive,
        "relay": relay.get("relay", "not_configured"),
        "pending": relay.get("pending", 0),
        "sent_total": relay.get("sent_total", 0),
        "relay_error": (relay.get("last_error") or "")[:200],
        "last_sent_at": relay.get("last_sent_at", 0),
        "phase": _phase,
        "message": _message,
        "acc_state": acc_state,
        "acc_total": acc_total,
        "acc_expired": acc_expired,
        "otp_today": otp_today,
        "accounts": accounts,
    }


def _status_thread():
    while True:
        try:
            data = _collect_status()
            tmp = _STATUS_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f)
            os.replace(tmp, _STATUS_FILE)
        except Exception as e:
            print(f"[android_hooks] status write failed: {e}", flush=True)
        time.sleep(3)


def _resolve_account(email):
    """Find the account row for this email, creating it on first login."""
    conn = _get_db()
    try:
        if email:
            row = conn.execute(
                "SELECT id FROM ivas_accounts WHERE lower(email)=lower(?)", (email,)
            ).fetchone()
            if row:
                return row["id"]
            cur = conn.execute(
                "INSERT INTO ivas_accounts (email, password, login_retries, status)"
                " VALUES (?, '', 0, 'Active')",
                (email,),
            )
            conn.commit()
            _log(f"New account added from app login: {email}", "success")
            return cur.lastrowid

        rows = conn.execute("SELECT id FROM ivas_accounts").fetchall()
        if len(rows) == 1:
            return rows[0]["id"]
        return None
    finally:
        conn.close()


def _handle_session_file(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)

        email = (payload.get("email") or "").strip()
        cookie = payload.get("cookie") or ""
        ua = payload.get("ua") or ""
        ws_token = payload.get("ws_token") or ""
        ws_user = payload.get("ws_user") or ""
        csrf = payload.get("csrf_token") or ""

        if not cookie:
            _log("Ignored an app session with no cookies.", "warning")
            return

        account_id = _resolve_account(email)
        if not account_id:
            _log("Could not match the captured session to an account - "
                 "add the email in the app before logging in.", "error")
            return

        _grace[account_id] = time.time() + GRACE_SECONDS

        ok = _apply_session(account_id, cookie, ua, ws_token, ws_user, csrf)
        if ok:
            _notified.pop(account_id, None)
            _log(f"App login applied for {email or account_id}.", "success")
            if _notify_admins:
                _notify_admins(
                    f"✅ <b>Session Restored</b>\n\nAccount: <code>{email or account_id}</code>",
                    parse_mode="HTML",
                )
    except Exception:
        return


def _drain_inbox_once():
    for name in sorted(os.listdir(_INBOX_DIR)):
        if not name.endswith(".json"):
            continue
        path = os.path.join(_INBOX_DIR, name)
        try:
            _handle_session_file(path)
        except Exception as e:
            _log(f"inbox {name} failed: {e}", "error")
            traceback.print_exc()
        finally:
            try:
                os.remove(path)
            except Exception:
                pass


def _inbox_thread():
    global _first_drain_done
    while True:
        try:
            _drain_inbox_once()
            _first_drain_done = True
        except Exception as e:
            print(f"[android_hooks] inbox scan failed: {e}", flush=True)
        time.sleep(3)


def start(apply_session=None, get_db=None, get_bd_time=None, add_log=None,
          notify_admins=None, validate_session=None, relay_state=None):
    global _started, _STATE_DIR, _INBOX_DIR, _STATUS_FILE, _first_drain_done
    global _apply_session, _validate_session, _relay_state, _get_db
    global _get_bd_time, _add_log, _notify_admins
    if _started:
        return
    _started = True

    _apply_session = apply_session
    _validate_session = validate_session
    _relay_state = relay_state
    _get_db = get_db
    _get_bd_time = get_bd_time
    _add_log = add_log
    _notify_admins = notify_admins

    _STATE_DIR = os.path.join(os.getcwd(), "app_state")
    _INBOX_DIR = os.path.join(_STATE_DIR, "inbox")
    _STATUS_FILE = os.path.join(_STATE_DIR, "status.json")
    os.makedirs(_INBOX_DIR, exist_ok=True)

    try:
        _drain_inbox_once()
    except Exception as e:
        print(f"[android_hooks] initial inbox drain failed: {e}", flush=True)
    _first_drain_done = True

    threading.Thread(target=_status_thread, daemon=True).start()
    threading.Thread(target=_inbox_thread, daemon=True).start()
    _log("Android bridge threads started.", "info")
