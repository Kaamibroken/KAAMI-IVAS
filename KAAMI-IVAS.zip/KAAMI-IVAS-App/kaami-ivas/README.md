# KAAMI-IVAS

Android app (Kotlin UI + Python engine via Chaquopy) that keeps your iVAS sessions
open, listens for incoming SMS and forwards every OTP to your server.

## Build (Android Studio)
1. Open this folder in Android Studio (Koala / 2024.1 or newer). It creates the Gradle wrapper itself.
2. Let Gradle sync (first sync downloads Chaquopy + Python packages, needs internet).
3. Run on a device, or Build > Build APK.

## Release signing (do this once, keep the file safe)
```
keytool -genkeypair -v -keystore kaami-release.jks -alias kaami \
        -keyalg RSA -keysize 2048 -validity 10000
```
Create `keystore.properties` next to `settings.gradle.kts`:
```
storeFile=kaami-release.jks
storePassword=YOUR_PASSWORD
keyAlias=kaami
keyPassword=YOUR_PASSWORD
```
Then: Build > Generate Signed App Bundle / APK, or `./gradlew assembleRelease`.
Package name is `com.kaami.ivas`, so it installs next to the old NM-IVAS app.

## How it works
- `MainActivity` saves Server URL + API key to `app_state/control.json`.
- `ForwarderService` (process `:bot`) starts `python/bridge.py` -> `forwarder_main.boot()`.
- "Add account" opens the iVAS login in a WebView. When the portal loads, cookies + user-agent
  are written to `app_state/inbox/*.json`; the engine picks them up, stores the session,
  opens the live-SMS socket and the screen closes itself.
- Every OTP goes into a SQLite outbox first, then `POST {server}/v1/push`
  with `Authorization: Bearer <API key>`; heartbeat goes to `/v1/heartbeat`.
- Engine state is written to `app_state/status.json` every 3 s and drives the UI.

## Server contract (unchanged from the old app)
`POST /v1/push`  body `{"otps":[{dedup_id, number, otp, service, range, country, language, body, received_at}]}`
-> 200/201 `{"accepted": N}`; 401/403 = key rejected. `POST /v1/heartbeat` every 60 s.
